<h2>
    <a href="https://yellowweb.top/donate" target="_blank">
        Version: 27.08.2022
        <br/>
        PHP Version: <?=phpversion()?>
        <br/> Please, donate!
    </a>
</h2>
