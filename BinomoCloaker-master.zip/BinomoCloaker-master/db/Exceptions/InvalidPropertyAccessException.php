<?php

namespace SleekDB\Exceptions;

/**
 * Class InvalidPropertyAccessException
 * @deprecated since version 2.7.
 */
class InvalidPropertyAccessException extends \Exception
{
}
