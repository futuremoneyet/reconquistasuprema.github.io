<?php

namespace Noodlehaus\Exception;

use Noodlehaus\Exception;

class FileNotFoundException extends Exception
{
}
