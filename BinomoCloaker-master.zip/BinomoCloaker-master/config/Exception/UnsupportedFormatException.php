<?php

namespace Noodlehaus\Exception;

use Noodlehaus\Exception;

class UnsupportedFormatException extends Exception
{
}
