<?php

namespace Noodlehaus;

class Exception extends \Exception
{
}
