<?php
declare(strict_types=1);

namespace Offdev\Bandit\Exceptions;

class RuntimeException extends \RuntimeException
{
}
