$(document).ready(function(){
  $('.carousel').slick({
  slidesToShow: 3,
  dots:true,
  centerMode: false,
  variableWidth: true,
  autoplay: true,
  autoplaySpeed: 2000
  });
});